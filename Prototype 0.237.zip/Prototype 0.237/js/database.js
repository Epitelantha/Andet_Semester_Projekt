function Database() {
    
};

Database.prototype.create = function() {
    
};

Database.prototype.list = function() {
    
};

Database.prototype.delete = function() {
    
};

Database.prototype.update = function() {
    
};